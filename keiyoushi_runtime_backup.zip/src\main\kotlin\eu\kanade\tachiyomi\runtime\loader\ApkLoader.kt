package eu.kanade.tachiyomi.runtime.loader

import com.googlecode.dex2jar.tools.Dex2jarCmd
import org.objectweb.asm.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkLoader {

    fun loadApk(apkFile: File): File {
        val tempJar = File.createTempFile("ext_dex2jar_", ".jar")
        tempJar.deleteOnExit()

        try {
            val cmd = Dex2jarCmd()
            val args = arrayOf("-f", "-o", tempJar.absolutePath, apkFile.absolutePath)
            cmd.doMain(*args)
        } catch (e: Exception) {
            println("[ApkLoader] Dex2jar failed for ${apkFile.name}: ${e.message}")
            throw e
        }

        val processedJar = File.createTempFile("ext_processed_", ".jar")
        processedJar.deleteOnExit()

        ZipInputStream(tempJar.inputStream()).use { zis ->
            ZipOutputStream(FileOutputStream(processedJar)).use { zos ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name
                    if (entryName.endsWith(".class")) {
                        val bytes = zis.readBytes()
                        val modifiedBytes = processClassBytes(bytes)
                        zos.putNextEntry(ZipEntry(entryName))
                        zos.write(modifiedBytes)
                        zos.closeEntry()
                    } else {
                        zos.putNextEntry(ZipEntry(entryName))
                        zis.copyTo(zos)
                        zos.closeEntry()
                    }
                    entry = zis.nextEntry
                }
            }
        }

        return processedJar
    }

    private fun processClassBytes(bytes: ByteArray): ByteArray {
        val reader = ClassReader(bytes)
        // COMPUTE_FRAMES rewrites all stack map frames — required when changing INVOKEVIRTUAL→INVOKESTATIC.
        val writer = object : ClassWriter(reader, COMPUTE_FRAMES) {
            override fun getCommonSuperClass(type1: String, type2: String): String =
                try { super.getCommonSuperClass(type1, type2) } catch (_: Throwable) { "java/lang/Object" }
        }
        return try {
            // EXPAND_FRAMES fully inflates compressed frames before recomputing them.
            reader.accept(buildVisitor(writer), ClassReader.EXPAND_FRAMES)
            writer.toByteArray()
        } catch (e: Throwable) {
            val className = try { reader.className } catch (_: Throwable) { "?" }
            println("[ApkLoader] COMPUTE_FRAMES failed for $className — returning original bytes")
            bytes
        }
    }

    /** Builds the rewriting ClassVisitor against the given writer. Extracted so we can reuse for fallback. */
    private fun buildVisitor(writer: ClassWriter): ClassVisitor {
        return object : ClassVisitor(Opcodes.ASM9, writer) {
            private var currentClassName: String = ""

            override fun visit(
                version: Int, access: Int, name: String,
                signature: String?, superName: String?, interfaces: Array<out String>?
            ) {
                currentClassName = name
                super.visit(version, access, name, signature, superName, interfaces)
            }

            override fun visitMethod(
                access: Int, name: String?, descriptor: String?,
                signature: String?, exceptions: Array<out String>?
            ): MethodVisitor {
                val currentMethodName = name ?: ""
                val mv = super.visitMethod(access, name, descriptor, signature, exceptions)
                return object : MethodVisitor(Opcodes.ASM9, mv) {
                    override fun visitTypeInsn(opcode: Int, type: String) {
                        var targetType = type
                        if (opcode == Opcodes.NEW && type == "kotlin/jvm/internal/Lambda") {
                            if (currentClassName.isNotEmpty()) {
                                targetType = currentClassName
                                println("[ApkLoader] Rewrote NEW kotlin/jvm/internal/Lambda -> NEW $currentClassName")
                            }
                        }
                        super.visitTypeInsn(opcode, targetType)
                    }

                    override fun visitMethodInsn(
                        opcode: Int, owner: String?, name: String?,
                        descriptor: String?, isInterface: Boolean
                    ) {
                        if (opcode == Opcodes.INVOKESTATIC && owner == "kotlinx/serialization/json/okio/OkioStreamsKt" && name == "decodeFromBufferedSource") {
                            super.visitMethodInsn(
                                Opcodes.INVOKESTATIC,
                                "eu/kanade/tachiyomi/network/OkHttpExtensionsKt",
                                "decodeFromBufferedSource",
                                "(Lkotlinx/serialization/json/Json;Lkotlinx/serialization/DeserializationStrategy;Lokio/BufferedSource;)Ljava/lang/Object;",
                                false
                            )
                            println("[ApkLoader] Rewrote OkioStreamsKt.decodeFromBufferedSource -> OkHttpExtensionsKt.decodeFromBufferedSource")
                            return
                        }
                        if (name == "sortedWith" && (owner?.contains("CollectionsKt") == true)) {
                            super.visitMethodInsn(
                                Opcodes.INVOKESTATIC,
                                "eu/kanade/tachiyomi/network/OkHttpExtensionsKt",
                                "safeSortedWith",
                                "(Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/util/List;",
                                false
                            )
                            println("[ApkLoader] Rewrote CollectionsKt.sortedWith -> OkHttpExtensionsKt.safeSortedWith")
                            return
                        }
                        if (name == "decodeFromString" && (owner == "kotlinx/serialization/json/Json" || owner == "kotlinx/serialization/StringFormat")) {
                            super.visitMethodInsn(
                                Opcodes.INVOKESTATIC,
                                "eu/kanade/tachiyomi/network/OkHttpExtensionsKt",
                                "decodeFromString",
                                "(Lkotlinx/serialization/json/Json;Lkotlinx/serialization/DeserializationStrategy;Ljava/lang/String;)Ljava/lang/Object;",
                                false
                            )
                            println("[ApkLoader] Rewrote Json.decodeFromString -> OkHttpExtensionsKt.decodeFromString")
                            return
                        }
                        if (name?.contains("maxAge") == true) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "eu/kanade/tachiyomi/network/OkHttpExtensionsKt", "customMaxAge", "(Lokhttp3/CacheControl\$Builder;J)Lokhttp3/CacheControl\$Builder;", false); return
                        }
                        if (name?.contains("maxStale") == true) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "eu/kanade/tachiyomi/network/OkHttpExtensionsKt", "customMaxStale", "(Lokhttp3/CacheControl\$Builder;J)Lokhttp3/CacheControl\$Builder;", false); return
                        }
                        if (name?.contains("minFresh") == true) {
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "eu/kanade/tachiyomi/network/OkHttpExtensionsKt", "customMinFresh", "(Lokhttp3/CacheControl\$Builder;J)Lokhttp3/CacheControl\$Builder;", false); return
                        }
                        if (opcode == Opcodes.INVOKEVIRTUAL && name == "serializer") {
                            val parameterCount = Type.getArgumentTypes(descriptor).size
                            if (parameterCount == 1) {
                                super.visitLdcInsn(owner ?: "")
                                super.visitMethodInsn(Opcodes.INVOKESTATIC, "eu/kanade/tachiyomi/network/OkHttpExtensionsKt", "getSerializer1", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;", false); return
                            } else if (parameterCount == 0) {
                                super.visitLdcInsn(owner ?: "")
                                super.visitMethodInsn(Opcodes.INVOKESTATIC, "eu/kanade/tachiyomi/network/OkHttpExtensionsKt", "getSerializer0", "(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;", false); return
                            }
                        }
                        if (opcode == Opcodes.INVOKEVIRTUAL && owner == "java/lang/Object" && name == "getClass" && descriptor == "()Ljava/lang/Class;") {
                            val lbl = org.objectweb.asm.Label()
                            super.visitInsn(Opcodes.DUP)
                            super.visitJumpInsn(Opcodes.IFNONNULL, lbl)
                            super.visitInsn(Opcodes.POP)
                            super.visitLdcInsn(org.objectweb.asm.Type.getType("Ljava/lang/Object;"))
                            super.visitLabel(lbl)
                            super.visitMethodInsn(opcode, owner, name, descriptor, isInterface)
                            return
                        }
                        super.visitMethodInsn(opcode, owner, name, descriptor, isInterface)
                    }

                    override fun visitFieldInsn(opcode: Int, owner: String?, name: String?, descriptor: String?) {
                        if (opcode == Opcodes.GETFIELD && owner != null) {
                            val lbl = org.objectweb.asm.Label()
                            super.visitInsn(Opcodes.DUP)
                            super.visitJumpInsn(Opcodes.IFNONNULL, lbl)
                            super.visitInsn(Opcodes.POP)
                            super.visitLdcInsn(owner)
                            super.visitMethodInsn(
                                Opcodes.INVOKESTATIC,
                                "eu/kanade/tachiyomi/runtime/loader/FieldFixer",
                                "getNonNullTarget",
                                "(Ljava/lang/String;)Ljava/lang/Object;",
                                false
                            )
                            super.visitLabel(lbl)
                        }
                        super.visitFieldInsn(opcode, owner, name, descriptor)
                    }
                }
            }
        }
    }
}
