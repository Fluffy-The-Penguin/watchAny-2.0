package eu.kanade.tachiyomi.runtime.loader

import eu.kanade.tachiyomi.source.Source
import java.io.File
import java.util.jar.JarFile

object ExtensionLoader {
    private val loadedSources = mutableMapOf<String, Source>()

    fun loadJar(jarFile: File): Source? {
        if (!jarFile.exists()) return null
        try {
            val jar = JarFile(jarFile)
            val classNames = mutableListOf<String>()
            val entries = jar.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.name.endsWith(".class") && !entry.isDirectory) {
                    val className = entry.name
                        .removeSuffix(".class")
                        .replace('/', '.')
                    classNames.add(className)
                }
            }
            jar.close()

            val classLoader = ExtensionClassLoader(arrayOf(jarFile.toURI().toURL()), javaClass.classLoader)

            val mainClassName = classNames.firstOrNull { it.endsWith(".ExtensionGenerated") }
                ?: classNames.firstOrNull { it.contains("Extension") }

            if (mainClassName != null) {
                try {
                    val clazz = classLoader.loadClass(mainClassName)
                    val instance = clazz.getDeclaredConstructor().newInstance()
                    if (instance is Source) {
                        println("[ExtensionLoader] Successfully loaded source: ${instance.name} (id: ${instance.id})")
                        loadedSources[instance.id.toString()] = instance
                        return instance
                    }
                } catch (e: Throwable) {
                    println("[ExtensionLoader] Error instantiating $mainClassName: $e")
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            println("[ExtensionLoader] Error reading JAR ${jarFile.name}: $e")
            e.printStackTrace()
        }
        return null
    }

    fun getSource(id: String): Source? {
        return loadedSources[id]
    }

    fun getAllSources(): List<Source> {
        return loadedSources.values.toList()
    }
}
